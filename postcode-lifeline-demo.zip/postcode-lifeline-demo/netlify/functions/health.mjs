import { json, hasKey } from "../shared/nipost.mjs";
// The page switches to live mode only when this says the key is set up.
export default async () => json(200, { ok: hasKey(), service: "postcode-emergency" });
export const config = { path: "/api/health" };
