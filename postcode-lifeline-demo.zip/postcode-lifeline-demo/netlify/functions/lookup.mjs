import { json, normalise, hyphenate, callApi, errorResponse, isNotFound, extractLocation, lookupLevel, DEBUG } from "../shared/nipost.mjs";

export default async (req) => {
  if (req.method !== "GET") return json(405, { error: "Only GET requests are supported." });
  const url = new URL(req.url);
  const code = normalise(url.searchParams.get("code"));
  if (!code) return json(400, { error: "A postcode has 11 letters and numbers, like FC-02-A09-DB-09." });
  const h = hyphenate(code);
  try {
    const r = await callApi(`/lookup?code=${encodeURIComponent(h)}&level=${encodeURIComponent(lookupLevel)}`);
    const raw = DEBUG ? { raw: r.body } : {};
    if (r.status === 401 || r.status === 403) return json(502, { error: "NIPOST rejected the API key. Check POSTCODE_API_KEY in Netlify." , ...raw });
    if (r.status === 404 || isNotFound(r.body)) return json(200, { found: false, code: h, ...raw });
    if (!r.ok) return json(502, { error: `NIPOST returned HTTP ${r.status}.`, ...raw });
    const location = extractLocation(r.body);
    return json(200, { found: !!location, code: h, location, ...raw });
  } catch (e) { return errorResponse(e); }
};
export const config = { path: "/api/lookup" };
