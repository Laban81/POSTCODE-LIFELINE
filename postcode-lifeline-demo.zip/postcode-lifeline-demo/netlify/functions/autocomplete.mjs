import { json, callApi, errorResponse } from "../shared/nipost.mjs";

export default async (req) => {
  if (req.method !== "GET") return json(405, { error: "Only GET requests are supported." });
  const url = new URL(req.url);
  const q = String(url.searchParams.get("q") || "").toUpperCase().replace(/[^A-Z0-9-]/g, "").slice(0, 15);
  if (q.length < 2) return json(400, { error: "Type at least 2 characters." });
  try {
    const r = await callApi(`/search/autocomplete?q=${encodeURIComponent(q)}`);
    if (!r.ok) return json(502, { error: `NIPOST returned HTTP ${r.status}.` });
    return json(200, r.body);
  } catch (e) { return errorResponse(e); }
};
export const config = { path: "/api/autocomplete" };
