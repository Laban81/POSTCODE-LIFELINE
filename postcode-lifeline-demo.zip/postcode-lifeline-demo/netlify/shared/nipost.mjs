// Shared helpers for POSTCODE LIFELINE's Netlify Functions.
// The NIPOST key is read from Netlify's environment variables and never sent to the browser.

const BASE = (process.env.POSTCODE_API_BASE || "https://api.postcode.gov.ng/v1").replace(/\/+$/, "");
const LEVEL = process.env.POSTCODE_LOOKUP_LEVEL || "1";
export const DEBUG = process.env.DEBUG === "1";
export const lookupLevel = LEVEL;
export const hasKey = () => !!process.env.POSTCODE_API_KEY;

export function json(status, obj) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
  });
}

// Accepts "FC 02 A09 DB 09", "fc-02-a09-db-09" or "FC02A09DB09"; returns "FC02A09DB09" or null.
export function normalise(input) {
  const c = String(input || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  return /^[A-Z0-9]{11}$/.test(c) ? c : null;
}
// NIPOST's examples use hyphens: EK-01-A03-FK-01
export const hyphenate = c => `${c.slice(0, 2)}-${c.slice(2, 4)}-${c.slice(4, 7)}-${c.slice(7, 9)}-${c.slice(9)}`;

export async function callApi(p) {
  const key = process.env.POSTCODE_API_KEY;
  if (!key) { const e = new Error("not configured"); e.code = "NOKEY"; throw e; }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  try {
    const r = await fetch(BASE + p, { headers: { "X-API-Key": key, Accept: "application/json" }, signal: ctrl.signal });
    const text = await r.text();
    let body; try { body = JSON.parse(text); } catch { body = text; }
    return { status: r.status, ok: r.ok, body };
  } finally { clearTimeout(timer); }
}

export function errorResponse(e) {
  if (e.code === "NOKEY") return json(503, { error: "The NIPOST key isn't set up on this site yet." });
  return json(502, { error: e.name === "AbortError" ? "NIPOST did not respond in time." : "Could not reach NIPOST." });
}

// ---- Reading NIPOST's response ----
// The exact response format isn't confirmed yet, so this looks for the usual field names.
// Once a real response is seen, this is the one place to adjust.
function findValue(obj, names, depth = 0) {
  if (!obj || typeof obj !== "object" || depth > 6) return undefined;
  for (const [k, v] of Object.entries(obj)) {
    if (names.includes(k.toLowerCase()) && v !== null && typeof v !== "object") return v;
  }
  for (const v of Object.values(obj)) {
    if (v && typeof v === "object") { const f = findValue(v, names, depth + 1); if (f !== undefined) return f; }
  }
  return undefined;
}
function findGeoJsonPoint(obj, depth = 0) {
  if (!obj || typeof obj !== "object" || depth > 6) return null;
  const c = obj.coordinates;
  if (Array.isArray(c) && c.length >= 2 && typeof c[0] === "number") return { lng: c[0], lat: c[1] };
  for (const v of Object.values(obj)) {
    if (v && typeof v === "object") { const p = findGeoJsonPoint(v, depth + 1); if (p) return p; }
  }
  return null;
}
export function isNotFound(body) {
  if (!body || typeof body !== "object") return false;
  if (Array.isArray(body)) return body.length === 0;
  if (body.found === false || body.success === false || body.data === null) return true;
  if (Array.isArray(body.results) && body.results.length === 0) return true;
  if (Array.isArray(body.data) && body.data.length === 0) return true;
  return false;
}
export function extractLocation(body) {
  if (!body || typeof body !== "object") return null;
  let rec = Array.isArray(body) ? body[0]
    : (body.data ?? body.result ?? (Array.isArray(body.results) ? body.results[0] : body));
  if (Array.isArray(rec)) rec = rec[0];
  if (!rec || typeof rec !== "object") return null;
  let lat = Number(findValue(rec, ["lat", "latitude"]));
  let lng = Number(findValue(rec, ["lng", "lon", "long", "longitude"]));
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
    const p = findGeoJsonPoint(rec);
    if (p) { lat = p.lat; lng = p.lng; }
  }
  const names = ["locality", "area", "district", "neighbourhood", "neighborhood", "ward", "town", "city", "lga", "state"]
    .map(n => findValue(rec, [n])).filter(v => typeof v === "string" && v.trim());
  const area = [...new Set(names)].slice(0, 3).join(", ") || String(findValue(rec, ["name", "postcode", "code"]) || "Location found");
  const detail = findValue(rec, ["street", "street_name", "address", "description", "landmark"]);
  return { area, detail: typeof detail === "string" ? detail : "", lat: Number.isFinite(lat) ? lat : null, lng: Number.isFinite(lng) ? lng : null };
}
